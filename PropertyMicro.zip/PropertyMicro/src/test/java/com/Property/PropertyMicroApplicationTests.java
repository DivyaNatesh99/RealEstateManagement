package com.Property;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
