package com.Property.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Property.Entity.Property;
import com.Property.Repository.PropertyRepo;

@Service
public class PropertyServiceImpl implements PropertyService {
	
	@Autowired
	PropertyRepo repo;

	@Override
	public Property createProperty(Property property) {
		// TODO Auto-generated method stub
		return repo.save(property);
	}

	@Override
	public List<Property> getAllProperties() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Property getAllPropertiesByType(String pType) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public Property getAllPropertiesByLocality(String pLocality) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProperty(String pId) {
		// TODO Auto-generated method stub
		repo.deleteById(pId);
		
	}

	
}