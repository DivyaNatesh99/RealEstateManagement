package com.Property.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Property.Entity.Property;


@Service
public interface PropertyService {
	
	
	/*o	POST: /createProperty (Input: Property| Output:  Status) 
o	GET: /getAllProperties(Output: List of Properties) 
o	GET: /getAllPropertiesByType(Input: PropertyType | Output: List of Properties) 
o	GET: /getAllPropertiesByLocality(Input: Locality| Output: List of Properties)  
*/
	
	public Property createProperty(Property property);
	public List<Property> getAllProperties();
	public Property getAllPropertiesByType(String pType);
	public Property getAllPropertiesByLocality(String pLocality);
	public void deleteProperty(String pId);
	
	
	
	

}
