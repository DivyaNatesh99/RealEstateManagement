package com.customer.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.Entity.Customer;

import com.customer.Repository.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService 

  {

	@Autowired
	CustomerRepo repo;
	

	@Override
	public List<Customer> getCustomerDetails() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repo.save(customer);
	}

	@Override
	public Customer getCustById(int id) {
		// TODO Auto-generated method stub
		Customer cus = repo.findById(id).get();
		return cus;
	}

	

}
