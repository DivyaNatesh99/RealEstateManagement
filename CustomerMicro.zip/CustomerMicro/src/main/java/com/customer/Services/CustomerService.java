package com.customer.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.customer.Entity.Customer;


@Service
public interface CustomerService {
	
	
	public List<Customer> getCustomerDetails();
	public Customer createCustomer(Customer customer);
	public Customer getCustById(int id);
	
}
