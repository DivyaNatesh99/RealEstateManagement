package com.customer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.customer.Entity.Customer;
import com.customer.Entity.PropertyDTO;
import com.customer.Services.CustomerService;

@CrossOrigin
@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	@GetMapping("/get")
	public List<Customer> getCustomerDetails()
	{
		return service.getCustomerDetails();
	}
	
	@PostMapping("/create")
	public Customer createCustomer(@RequestBody Customer customer)
	{
		return service.createCustomer(customer);
	}
	
	@GetMapping("/getbyid/{id}")
	public Customer getById(@PathVariable int id)
	{
		return service.getCustById(id);
	}
	
	@GetMapping("/getProperties")
	public List<PropertyDTO> getProperties()
	{
		List<PropertyDTO> pro = null;
		
		String url ="http://localhost:8082/property/get";
		try {
			pro = restTemplate.getForObject(url,List.class);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return pro;
	}
	
	
	

}
